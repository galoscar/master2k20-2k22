function setlpc

global lpcPopUp

x = get(lpcPopUp,'Value')



