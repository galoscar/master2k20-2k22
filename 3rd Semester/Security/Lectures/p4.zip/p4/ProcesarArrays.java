package p4;

public class ProcesarArrays {

	    // PR�CTICA 4 EJERCICIO 1....................................................
		public static boolean elementosRepetidos(int a []){
				if (a == null || a.length == 1 || a.length == 0){
					return false;
				}
				for(int i = 0; i < a.length-1; i++){
				  for (int j=i+1; j<a.length;j++)
					if (a[i] == a[j]){
						return true;
					}
				}
				return false;
			}
	
	
	    // PR�CTICA 4 EJERCICIO 2 .............................................
		public static int busquedaLineal(int [] a, int clave){
			
			if (a == null || a.length == 0){
				return -1;
			}
			if (elementosRepetidos(a))
			  return -1;
			
			for(int i = 0; i < a.length; i++)
			    if (a[i]==clave) return i;
			
			return -1;
			
	      }
			
		 // PR�CTICA 4 EJERCICIO 3............................................................
		 public static int [] invertir(int a []){
					if (a == null || a.length==0){
						return null;
					}
					int b [] = new int[a.length];
					
					for (int i = 0; i < a.length; i++){
						b[i]= a[a.length-1-i];
					}
					//Para mostrar en pantalla el array invertido
					for (int i = 0; i < b.length; i++){
						System.out.print(b[i]);
					}
					return b;
				}
		
		 public static int [] invertir2(int a []){
				if (a == null || a.length==0){
					return null;
				}
				int aux = 0;
				for (int i = 0; i < a.length/2; i++){
					aux = a[i];
					a[i] = a[a.length-1-i];
					a[a.length-1-i] = aux;
				}
				//Para mostrar en pantalla el array invertido
				for (int i = 0; i < a.length; i++){
					System.out.print(a[i]);
				}
				return a;
			}
		
		
		// PR�CTICA 4 EJERCICIO 4..........................................................
		 public static boolean enOrden(int [] a, boolean ascendente){
				if (a == null || a.length == 0){
					return false;
				}
				if (ascendente){
					for (int i = 0; i < a.length - 1; i++){
						if (a[i] > a[i+1]){
							return false;
						}
					}
				}
				else {
					for (int i = 0; i < a.length - 1; i++){
						if (a[i] < a[i+1]){
							return false;
						}
					}			
				}
				return true;
		 }
		 
		 public static int [] ordenar(int [] a, boolean ascendente){
			if (a == null || a.length==0 || a.length==1){
				return null;
			}
			if (enOrden(a,ascendente)) return a;
			
			int b [] = new int[a.length];
			for (int i = 0; i < a.length; i++){
				b[i] = a[i];
			}
			int aux = 0;
			if (ascendente){
				for (int i = 0; i < b.length - 1; i++){
					for(int j = 0; j < b.length - 1 - i; j++){
						if (b[j] > b[j+1]){
							aux = b[j];
							b[j] = b[j+1];
							b[j+1] = aux;
						}
					}
				}
			}
			else {
				for (int i = 0; i < b.length - 1; i++){
					for(int j = 0; j < b.length - 1 - i; j++){
						if (b[j] < b[j+1]){
							aux = b[j];
							b[j] = b[j+1];
							b[j+1] = aux;
						}
					}
				}					
			}
			//Para mostrar el array ordenado en pantalla
			for (int i = 0; i<b.length; i++){
				System.out.print(b[i] + " ");
			}
			return b;
		}
		
		
		
		// PR�CTICA 4 EJERCICIO 5.......................................................
		public static int cuentaOcurrencias(int [] a, int k){
			if (a == null || a.length==0){
				return 0;
			}
			int cont = 0;
			for(int i = 0; i < a.length; i++){
				if (a[i] == k){
					cont++;
				}
			}
			return cont;
		}
		
		public static int [] eliminarK(int [] a, int k){
			if (a == null){
				return null;
			}
			if (a.length==0) {
				return new int[0];
			}
			int tam = a.length - cuentaOcurrencias(a, k);
			int res [] = new int[tam];
			int index = 0;
			for (int i = 0; i < a.length; i++){
				if (a[i] != k){
					res[index] = a[i];
					index++;
				}
			}
			//Para mostrar el array resultante en pantalla
			for (int i=0; i<res.length; i++)
				System.out.print(res[i] + " ");
			return res;
		}	
		
		// PRACTICA 4 EJERCICIO 6................................................
		public static int [] alternarElementos(int [] a, int [] b){
			
			if (a==null || a.length==0 || b==null || b.length==0) return null;
			if (a.length!=b.length) return null;
			
			int [] resultado = new int [a.length+b.length];
			int j = 0;
			for (int i=0; i<resultado.length-1; i+=2){
				if (j<a.length){ 
				 resultado[i] = a[j];
				 resultado[i+1] = b[j];
				}
				j++;
			}
			
			return resultado;
		}
		
		
		// PRACTICA 4 EJERCICIO 7.......................
		public static int [] indices(int a [], int n){
			if (a==null || a.length==0) return null;
			int cont = 0;
			for (int i=0; i<a.length; i++)
				if (a[i]==n) cont++;
			
			if (cont==0) return null;
			
			int resultado [] = new int[cont];
			
			int j=0; 
			for (int i=0; i<a.length; i++){
				 if (a[i]==n) {
			       resultado[j]=i;
				   j++;
				 };
			}
			
			for (int i=0; i<cont; i++){
				System.out.println(resultado[i]);
			}
			return resultado;

	   }
    
    // PR�CTICA 4 EJERCICIO 8.....................................................
    /**
     * Devuelve un matriz resultado de haber eliminado la fila
     * n-�sima de la matriz m pasada como argumento.
     * @param m matriz
     * @param n n�mero de fila
     * @return matriz resultado de haber eliminado la fila
     *         n-�sima de la matriz m pasada como argumento.
     * 		   null si m no es matriz o no existe la fila.
     */
    public static double [][] quitarFila(double [][] m, int n){
        if (m == null){
            return null;
        }
        if(!Matrices.esMatriz(m)){
            return null;
        }
        if (m.length == 0){
            return null;
        }
        if (n >= m.length || n < 0){
            return null;
        }
        double [][] res = new double[m.length - 1][m[0].length];
        for(int i = 0; i < res.length; i++){
            for(int j = 0; j < res[i].length; j++){
                if (i < n){
                    res[i][j] = m[i][j];
                }
                else if (i >= n && i+1 < m.length){
                    res[i][j] = m[i+1][j];
                }
            }
        }
        return res;
    }
    
    
    // PR�CTICA 4 EJERCICIO 9.....................................................
    /**
     * Devuelve un matriz resultado de haber eliminado la
     * n-�sima columna de la matriz m pasada como argumento.
     * @param m matriz
     * @param n columna
     * @return matriz resultado de haber eliminado la
     *         n-�sima columna de la matriz m pasada como argumento..
     * 		   null si m no e matriz o no existe la columna.
     */
    public static double [][] quitarCol(double [][] m, int n){
        if (m == null){
            return null;
        }
        if(!Matrices.esMatriz(m)){
            return null;
        }
        if (m.length == 0){
            return null;
        }
        if (n >= m[0].length || n < 0){
            return null;
        }
        double [][] res = new double[m.length][m[0].length - 1];
        for(int i = 0; i < res.length; i++){
            for(int j = 0; j < res[i].length; j++){
                if (j < n){
                    res[i][j] = m[i][j];
                }
                else if (j >= n && j+1 < m[0].length){
                    res[i][j] = m[i][j+1];
                }
            }
        }
        return res;
    }
    
    // PR�CTICA 4 EJERCICIO 10......................................................
    /**
     * Dado un determinante de orden n, se llama menor complementario del
     * elemento aij, al determinante de orden n-1 que resulta de suprimir
     * en el determinante dado la fila i-�sima y la columna j-�sima.
     * @param m determinante de orden n
     * @param i	�ndice de fila (aij)
     * @param j �ndice de columna (aij)
     * @return array de dos dimensiones con los elementos del menor complementario de m.
     *         null si m no es matriz o i y j no representan una fila y columna v�lidas.
     */
    public static double [][] menorComplementario (double [][] m, int i, int j){
        if (!Matrices.esMatriz(m)){
            return null;
        }
        double [][] res = quitarFila(m, i);
        if (res == null){
            return null;
        }
        res = quitarCol(res, j);
        return res;
    }
    
    
    
		public static void main(String args[]){
			
			Test4.test_quitarFila();
			Test4.test_quitarColumna();
			Test4.test_getMenorComplementario();
		}
}
		
		