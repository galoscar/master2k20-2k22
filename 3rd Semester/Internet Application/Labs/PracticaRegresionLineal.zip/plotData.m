function plotData(x, y)
%   PLOTDATA(x,y) representa los datos de beneficio "y" frente a poblaci�n
%   "x"

% ====================== ESCRIBE AQUI TU CODIGO ======================
% Instrucciones: Representa "x" frente a "y" mediante los comandos
%               "figure" y "plot". Usa los comandos "xlabel" y "ylabel" 
%               para indicar las etiquetas de cada eje.
%

 % abre una ventana "figure"

 % representa la figura
 % indica la etiqueta del eje y
 % indica la etiqueta del eje x

% ============================================================

end
